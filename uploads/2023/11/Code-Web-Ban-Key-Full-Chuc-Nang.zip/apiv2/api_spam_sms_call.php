<?php
if (isset($_POST['phone'])) {
    $phone = $_POST['phone'];
    
    if ($_POST['server'] == 'server1') {
        $time_limit = 60;
        $blacklist = array(
            '0335395153',
            '0399498820',
            '0385315877',
            '0777374145'
        );
        if (empty($phone)) {
            echo '<script type="text/javascript">alert("Thiếu số điện thoại!"); setTimeout(function(){ location.href = "/" }, 1000);</script>';
        } else if (in_array($phone, $blacklist)) {
            echo '<script type="text/javascript">alert("Spam Thành Công!");</script>';
            echo '<script type="text/javascript">alert("Đùa Đấy tuổi gì mà đòi spam số anh😝!");</script>';
        } else {
            echo '<script type="text/javascript">alert("Spam Thành Công!");</script>';
            $data = array('phone' => $phone);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://api.huykaiser.me/API/AUTOSPAM/spam?count=100&apikey=HUYKAISER_CUTO_OK&phone=' . urlencode($phone));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            if ($_POST['server'] == 'server1') {
                $time_limit = 60;
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_limit);
            } else if ($_POST['server'] == 'server2') {
                $time_limit = 120;
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_limit);
            } else {
                echo '<script type="text/javascript">alert("Server không hợp lệ!");</script>';
                exit();
            }

            $response = curl_exec($ch);
            curl_close($ch);
        }
    }
} else {
    echo '<script type="text/javascript">alert("Trường Phone Không Được Để Trống!");</script>';
}
?>