<?php
error_reporting(0);
session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");
if (isset($_GET['get_token']) && $_GET['get_token'] == 'EAAG' && !isset($_GET['namefb']) && isset($_GET['cookie'])) {
    $cookie = urldecode($_GET['cookie']);
    $get = dragonx_get_token($cookie);
    echo $get;
} elseif (isset($_GET['namefb']) && !isset($_GET['get_token']) && isset($_GET['cookie'])) {
    $cookie = urldecode($_GET['cookie']);
    $get = dragonx_get_token($cookie);
    $tenfb = json_decode(file_get_contents('https://graph.facebook.com/me/?access_token=' . $get))->{'name'};
    echo $tenfb;
} elseif (isset($_GET['create_key_free'])){
$today = date("d-m-Y");
$a = file_get_contents("https://shopdragonx.com/api/abk.php?type=a");
$b = file_get_contents("https://shopdragonx.com/api/abk.php?type=b");
$key = "DRAGONX-".strtoupper(substr(md5($today), 0 , 7))."-".$a.$b;
$long_url = urlencode('https://shopdragonx.com/key/?key='.$key);
$api_token = '645345e99f31dc60c1178671';
$api_url = "https://link4m.co/api-shorten/v2?api={$api_token}&url={$long_url}";
$result = @json_decode(file_get_contents($api_url),TRUE);
die(json_encode([
    "status" => "success",
    "key" => $key,
    "link" => $result["shortenedUrl"]
    ]));
} elseif (isset($_GET['thoi_tiet'])){
$ip = $_GET['ip'];
if (empty($ip) || $ip == ""){
    $ip = $_SERVER['REMOTE_ADDR'];
}
$url = "https://ipinfo.io/$ip?token=d8ac9aacb729da";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response);
$city = $data->city;
$country_name = $data->country;
$region_name = $data->region;
$weatherUrl = "http://api.openweathermap.org/data/2.5/weather?q=$city&appid=b6b8132241c2288d8100ace8987a0314";
$weatherData = file_get_contents($weatherUrl);
$weather = json_decode($weatherData);
$temperature = $weather->main->temp;
$humidity = $weather->main->humidity;
$windDegree = $weather->wind->deg;
$windSpeed = $weather->wind->speed;
$weatherDescription = $weather->weather[0]->description;
$temperatureKelvin = $temperature;
$temperatureCelsius = $temperatureKelvin - 273.15;
$dayOfWeek = date("N");
$dayNames = array(
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday',
    6 => 'Saturday',
    7 => 'Sunday'
);
$directions = array(
    array('name' => 'North', 'min' => 337.5, 'max' => 22.5),
    array('name' => 'North East', 'min' => 22.5, 'max' => 67.5),
    array('name' => 'East', 'min' => 67.5, 'max' => 112.5),
    array('name' => 'South East', 'min' => 112.5, 'max' => 157.5),
    array('name' => 'South', 'min' => 157.5, 'max' => 202.5),
    array('name' => 'South West', 'min' => 202.5, 'max' => 247.5),
    array('name' => 'West', 'min' => 247.5, 'max' => 292.5),
    array('name' => 'North West', 'min' => 292.5, 'max' => 337.5)
);
$windDirection = '';
foreach ($directions as $direction) {
    if ($windDegree >= $direction['min'] && $windDegree < $direction['max']) {
        $windDirection = $direction['name'];
        break;
    }
}
die(json_encode([
    "status" => "success",
    "city" => $city,
    "region_name" => $region_name,
    "country_name" => $country_name,
    "dayOfWeek" => $dayNames[$dayOfWeek],
    "temperatureCelsius" => round($temperatureCelsius),
    "weatherDescription" => $weatherDescription,
    "humidity" => $humidity,
    "windSpeed" => $windSpeed,
    "windDirection" => $windDirection,
    "notedAt" => date("H:i:s")
    ]));
} elseif (isset($_GET['what_is_my_ip_'])){
echo $_SERVER['REMOTE_ADDR'];
} else {
echo "Hello ";
$ntn = date("d-m-Y");
$ip = $_SERVER['REMOTE_ADDR'];
$a = "warning : $ip";
$file = fopen("warning:$ntn.txt", "w+");
    fwrite($file, $a);
    fclose($file);
}

function dragonx_get_token($cookie) {
    $useragent = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36';
    $head= array("Connection: keep-alive","Keep-Alive: 300","authority: business.facebook.com","ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7","accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5","cache-control: max-age=0","upgrade-insecure-requests: 1","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document");
$ch=curl_init();
	curl_setopt_array($ch , array(
		CURLOPT_URL => "https://business.facebook.com/business_locations",
		CURLOPT_USERAGENT => $useragent,
		CURLOPT_COOKIE => $cookie,
		CURLOPT_HTTPHEADER => $head,
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_SSL_VERIFYPEER => FALSE,
		CURLOPT_TIMEOUT => 60,
		CURLOPT_CONNECTTIMEOUT => 60,
		CURLOPT_FOLLOWLOCATION => TRUE
	));
	$access = curl_exec($ch);
	curl_close($ch);
$access_token = 'EAAG'.explode('","', explode('EAAG', $access)[1])[0];
if(strlen($access_token) > 5){
	return $access_token;
} else {
	return 'die';
}
}
?>
