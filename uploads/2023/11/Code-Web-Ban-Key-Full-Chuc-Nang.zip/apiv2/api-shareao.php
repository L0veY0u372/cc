<?php
date_default_timezone_set("Asia/Ho_Chi_Minh");
$useragent = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36';
$id = $_POST['idbv'];
$dung = $_POST['soluong'];
$ck = $_POST['cookie'];
$stt = 0;
while(true){
    $tk = dragonx_laytoken($ck, $useragent);
    if ($tk == "die"){
        echo '<span style="color: red;">Cookie Die Rồi!</span><br>';
        continue;
    } else {
        break;
    }
}
while(true){
    $share = share($tk,$id,$ck);
    $id_s = $share["id"] ;
    if (!$id_s){
        echo '<span style="color: red;">Share Thất Bại ! Kiểm Tra Lại Acc Hoặc ID Bài Viết</span><br>';
    } else {
        $stt++;
        echo '<span style="color: green;">[' . $stt . '] SHARED SUCCESS</span><br>';
        if ( $stt == $dung ){
            echo '<span style="color: red;">Đã Chạy Hoàn Thành $stt Share</span><br>';
            exit;
        }
    }
}

function dragonx_laytoken($ck, $useragent) {
    $head= array("Connection: keep-alive","Keep-Alive: 300","authority: business.facebook.com","ccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7","accept-language: vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5","cache-control: max-age=0","upgrade-insecure-requests: 1","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document");
    $ch=curl_init();
    curl_setopt_array($ch , array(
        CURLOPT_URL => "https://business.facebook.com/business_locations",
        CURLOPT_USERAGENT => $useragent,
        CURLOPT_COOKIE => $ck,
        CURLOPT_HTTPHEADER => $head,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_SSL_VERIFYPEER => FALSE,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_CONNECTTIMEOUT => 60,
        CURLOPT_FOLLOWLOCATION => TRUE
    ));
    $access = curl_exec($ch);
    curl_close($ch);
    $access_token = 'EAAG'.explode('","', explode('EAAG', $access)[1])[0];
    if(strlen($access_token) > 5){
        return $access_token;
    } else {
        return 'die';
    }
}

function share($tk,$id,$ck) {
    $url = "https://graph.facebook.com/me/feed?link=https://m.facebook.com/".$id."&published=0&access_token=".$tk;
    
    $tsm = array (
        'accept: */*',
        'accept-encoding: gzip, deflate',
        'connection: keep-alive',
        'content-length: 0',
        'cookie:'.$ck,
        'host: graph.facebook.com',
    );
    $mr = curl_init();
    curl_setopt_array($mr, array(
        CURLOPT_PORT => "443",
        CURLOPT_URL => "$url",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => $tsm
    ));
    $mr2 = curl_exec($mr); curl_close($mr);
    $js = json_decode($mr2,true);
    return $js;
}
?>