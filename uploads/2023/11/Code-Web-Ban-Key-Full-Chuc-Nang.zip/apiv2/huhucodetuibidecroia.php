<?php
$ip = $_SERVER['REMOTE_ADDR'];

function banvpn() {
    $vpn = shell_exec('ifconfig');
    if (preg_match("/tun0/i", $vpn)) {
        die(json_encode([
                "status" => "error",
                "msg" => "Vui Lòng Tắt VPN"
            ]));
    }
}

function bandip($ip) {
    $oldContent = file_get_contents("list_ip_block.txt");
    $newContent = $oldContent . "|" . $ip;
    file_put_contents("list_ip_block.txt", $newContent);
}

function kiemtraip($ip) {
    $layfile = file_get_contents("list_ip_block.txt");
    if (preg_match("/$ip/i", $layfile)) {
        die(json_encode([
                "status" => "error",
                "msg" => "You Have Been Banned"
            ]));
    }
}

function get_link_code($access_token, $ip) {
    $key = "DRAGONX/TZBIMJF4V1UJ6YXDAIZQ07GT1VPAAPEEJGIey";
    if ($access_token == $key) {
        $link = $_POST['requests_link'];
        if ($link == "ttcck") {
            die(json_encode([
                "status" => "success",
                "msg" => "https://run.mocky.io/v3/c4c5b859-4e92-4162-adcd-f98a1699478c"
            ]));
        } else if ($link == "ttctt") {
            die(json_encode([
                "status" => "success",
                "msg" => "https://run.mocky.io/v3/c4c5b859-4e92-4162-adcd-f98a1699478c"
            ]));
        } else {
            bandip($ip);
            die(json_encode([
                "status" => "error",
                "msg" => "You Have Been Banned"
            ]));
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {
    bandip($ip);
    include $_SERVER['DOCUMENT_ROOT'] . '/public/client/pages/404.php';
    die();
} else {
    banvpn();
    kiemtraip($ip);
    $access_token = isset($_POST['access_token']) ? $_POST['access_token'] : '';
    get_link_code($access_token, $ip);
}
?>
