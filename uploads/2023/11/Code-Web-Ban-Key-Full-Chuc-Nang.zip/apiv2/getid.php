<?php
error_reporting(0);
echo file_get_contents("https://golike.com.vn/func-api.php?user=".$_GET['user']);