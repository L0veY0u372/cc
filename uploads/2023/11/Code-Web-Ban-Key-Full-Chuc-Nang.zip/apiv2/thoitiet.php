<?php
$ip = file_get_contents("https://kiemtraip.com/raw.php");
$apiKey = 'f76febfdcafae6a5463ab4dc918f5b49';
$url = "http://api.ipstack.com/$ip?access_key=f76febfdcafae6a5463ab4dc918f5b49";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response);
$city = $data->city;
$country_name = $data->country_name;
$region_name = $data->region_name;
$weatherUrl = "http://api.openweathermap.org/data/2.5/weather?q=$city&appid=b6b8132241c2288d8100ace8987a0314";
$weatherData = file_get_contents($weatherUrl);
$weather = json_decode($weatherData);
$temperature = $weather->main->temp;
$humidity = $weather->main->humidity;
$windDegree = $weather->wind->deg;
$windSpeed = $weather->wind->speed;
$weatherDescription = $weather->weather[0]->description;
$temperatureKelvin = $temperature;
$temperatureCelsius = $temperatureKelvin - 273.15;
$dayOfWeek = date("N");
$dayNames = array(
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday',
    6 => 'Saturday',
    7 => 'Sunday'
);
$directions = array(
    array('name' => 'North', 'min' => 337.5, 'max' => 22.5),
    array('name' => 'North East', 'min' => 22.5, 'max' => 67.5),
    array('name' => 'East', 'min' => 67.5, 'max' => 112.5),
    array('name' => 'South East', 'min' => 112.5, 'max' => 157.5),
    array('name' => 'South', 'min' => 157.5, 'max' => 202.5),
    array('name' => 'South West', 'min' => 202.5, 'max' => 247.5),
    array('name' => 'West', 'min' => 247.5, 'max' => 292.5),
    array('name' => 'North West', 'min' => 292.5, 'max' => 337.5)
);
$windDirection = '';
foreach ($directions as $direction) {
    if ($windDegree >= $direction['min'] && $windDegree < $direction['max']) {
        $windDirection = $direction['name'];
        break;
    }
}
echo $vuhoang."⛅ Thời Tiết Tại ".$city.", ".$region_name." " . $country_name . " ⛅";
echo $vuhoang."📅 ".$dayNames[$dayOfWeek]." ".date("Y-m-d");
echo $vuhoang."🌡️ ️️ Nhiệt Độ : $vang" . $temperatureCelsius . " °C";
echo $vuhoang."💬 Mô Tả : $vang" . $weatherDescription."";
echo $vuhoang."💧 Độ Ẩm : $vang" . $humidity . "";
echo $vuhoang."🌀 Hướng Gió : $vang" . $windSpeed . "km/h " . $windDirection . "";
echo $vuhoang."📝 Ghi Nhận Lúc : $vang" .date("H:i:s")."\n";
?>