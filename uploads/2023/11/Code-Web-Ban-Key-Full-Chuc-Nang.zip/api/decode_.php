<?php
require('../config/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {
    include('../public/client/pages/404.php');
    die();
} else {
    $api = $_POST['token'];
    $mgg = $_POST['mgg'];
    //$mgg = addslashes($_POST['mgg']);
    //$file = $_FILES["fileToUpload"]["name"];
    $file = $_FILES['fileToUpload'];

    $check_users = $ManhDev->query("SELECT * FROM `users` WHERE `apitoken` = '$api' ")->fetch_array();
    if ($mgg == "khai_truong_decode2023") {
        $tong_tien = 50000 - (50000 * 20 / 100);
    } else {
        $tong_tien = 50000;
    }

    if (empty($file) || empty($api)) {
        die(json_encode([
            "status" => "error",
            "msg" => "Vui Lòng Nhập Đầy Đủ Thông Tin!"
        ]));
    } else if (!$check_users) {
        die(json_encode([
            "status" => "error",
            "msg" => "Token Api Không Tồn Tại"
        ]));
    } else if ($check_users['money'] < $tong_tien) {
        die(json_encode([
            "status" => "error",
            "msg" => "Bạn Không Đủ " . tien($tong_tien) . "đ Để Thực Hiện Giao Dịch"
        ]));
    } else {
        $trutientt = $check_users['money'] - $tong_tien;
        $congtiendt = $check_users['tong_tru'] + $tong_tien;
    }
}

$targetDir = "uploads/";
$targetFile = $targetDir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
$rddir = rand(0, 9999999999);
mkdir($rddir, 755);

if (file_exists($targetFile)) {
    $uploadOk = 0;
    die(json_encode([
        "status" => "error",
        "msg" => "Tệp tin đã tồn tại."
    ]));
}

if ($_FILES["fileToUpload"]["size"] > 5000000) {
    $uploadOk = 0;
    die(json_encode([
        "status" => "error",
        "msg" => "Tệp tin quá lớn. Vui lòng tải lên tệp tin nhỏ hơn 5MB."
    ]));
}

if ($imageFileType !== "php") {
    $uploadOk = 0;
    die(json_encode([
        "status" => "error",
        "msg" => "Chỉ cho phép tải lên tệp tin với định dạng .php"
    ]));
}

if ($uploadOk == 1) {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
        $command = "cd " . $rddir . " && ~/php/php " . $targetFile . " & sleep 30; kill -INT $!";
        shell_exec($command);
            // Đường dẫn đến tệp tin bạn muốn nén
$fileToCompress = $rddir;

// Tên tệp tin nén (tên tệp tin và phần mở rộng tệp tin nén)
// Tạo tên file nén với số ngẫu nhiên
$zipFileName = $rddir . "_" . uniqid() . ".zip";



// Tạo đối tượng ZipArchive
$zip = new ZipArchive();

// Mở tệp tin nén để ghi
if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    // Thêm tệp tin bạn muốn nén vào tệp tin nén
    $zip->addFile($fileToCompress, basename($fileToCompress));

    // Đóng tệp tin nén
    $zip->close();

    // Thiết lập tiêu đề tệp tin để trình duyệt nhận diện nó là tệp tin nén
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
    header('Content-Length: ' . filesize($zipFileName));

    // Đọc và gửi dữ liệu tệp tin nén cho người dùng
    readfile($zipFileName);

    // Xóa tệp tin nén khỏi máy chủ (tùy chọn)
    //unlink($zipFileName);
            $ManhDev->update("users", [
            'money' => $trutientt,
            'tong_tru' => $congtiendt
            ], " `username` = '".$check_users['username']."' ");

$ManhDev->insert("decode_php", [
                'username'    => $check_users['username'],
                'giatien'        => $tong_tien,
                'namefile'    => $zipFileName,
                'time' => date("d-m-Y H:i:s")
                ]);

$ManhDev->insert("log_site", [
                'username'   => $check_users['username'],
                'type'       => 'decode',
                'note'       => 'Decode Thành Công',
                'ip'         => getip(),
                'useragent'  => $_SERVER["HTTP_USER_AGENT"],
                'time'       => date("d-m-Y H:i:s")
                ]);
                die(json_encode([
                'status' => 'success',
                'msg' => 'Decode Thành Công!',
                'giatien' => $tong_tien,
                'namefile' => $zipFileName,
                'time' => date("d-m-Y H:i:s")
    ]));
} else {
die(json_encode([
    "status" => "error",
    "msg" => "Không thể tạo tệp tin nén.!"]));
}
        } else {
        die(json_encode([
    "status" => "error",
    "msg" => "Có lỗi xảy ra khi tải lên tệp tin!"]));
        }
    }
?>
