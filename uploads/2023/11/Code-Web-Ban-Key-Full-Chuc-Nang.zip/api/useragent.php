<?php
$userAgent = $_SERVER['HTTP_USER_AGENT'];
echo $userAgent;
?>
