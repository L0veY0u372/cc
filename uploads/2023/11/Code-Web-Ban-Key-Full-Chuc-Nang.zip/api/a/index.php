<?php
#https://decode.shopdragonx.net/dec.php?type=enc&code=$__file__&key=vuhoangdev008
$key = "vuhoangdev008";
if ($_GET['type'] == "enc" and $_GET['key'] == $key){
$code = urldecode(file_get_contents($_GET['code']));
$dau_ra = encode_hash($code);
echo $dau_ra;
} elseif ($_GET['type'] == "dec" and $_GET['key'] == $key){
$code = urldecode(file_get_contents($_GET['code']));
$dau_ra = decode_hash($code);
echo $dau_ra;
} else {
echo "wrong";}
function encode_hash($code){
 # $code = base64_decode($code);   
  $code = base64_encode($code);
  $list = array('I','e','d','T','N','M','Y','S','v','q','W','O','Q','l','K','w','4','3','y','0','i','8','E','u','k','o','+','G','h','U','Z','7','m','D','A','J','6','s','H','/','f','L','1','C','p','=','g','X','a','x','B','5','V','j','b','r','t','c','9','R','2','z','F','P','n');
  $code = base64_encode($code);
  $code = str_replace($list,array('な','ぽ','ぼ','ね','ぐ','お','ぶ','ふ','す','あ','く','で','こ','ぢ','の','ぴ','ぬ','か','に','つ','ほ','と','が','せ','ご','う','い','じ','ち','も','ず','き','さ','む','は','ぷ','げ','づ','ゆ','ら','だ','り','や','け','び','べ','ぜ','ざ','ぎ','そ','ば','へ','よ','ぺ','ぱ','た','ひ','て','め','し','え','み','ぞ','ど','ま'),$code);      
  $code = base64_encode($code);
  $code = strrev($code);
  $code = base64_decode($code);
#return base64_decode('JF9fZmlsZV9f')." = '".$code."';".base64_decode('ZXZhbChmaWxlX2dldF9jb250ZW50cygiMTA0eDExNngxMTZ4MTEyeDExNXg1OHg0N3g0N3gxMDB4MTAxeDk5eDExMXgxMDB4MTAxeDQ2eDExNXgxMDR4MTExeDExMngxMDB4MTE0eDk3eDEwM3gxMTF4MTEweDEyMHg0NngxMTB4MTAxeDExNng0N3gxMDB4MTAxeDk5eDQ2eDExMngxMDR4MTEyeDYzeDExNngxMjF4MTEyeDEwMXg2MXgxMDR4OTd4MTE1eDEwNHgzOHg5OXgxMTF4MTAweDEwMXg2MXgzNng5NXg5NXgxMDJ4MTA1eDEwOHgxMDF4OTV4OTV4IikpOw==');
return $code;
}
function decode_hash($code){
   # $code = base64_decode($code);   
    $code = str_replace('eval(file_get_contents("104x116x116x112x115x58x47x47x100x101x99x111x100x101x46x115x104x111x112x100x114x97x103x111x110x120x46x110x101x116x47x100x101x99x46x112x104x112x63x116x121x112x101x61x104x97x115x104x38x99x111x100x101x61x36x95x95x102x105x108x101x95x95x"));'."", '', $code);
    $code = str_replace(base64_decode('JF9fZmlsZV9f')."", '', $code);
    $code = str_replace(" = '"."", '', $code);
    $code = str_replace("';"."", '', $code);
    $code = str_replace('='."", '', $code);
    $code = base64_encode($code);
    $code = strrev($code);
    $code = base64_decode($code);
    $list = array('な','ぽ','ぼ','ね','ぐ','お','ぶ','ふ','す','あ','く','で','こ','ぢ','の','ぴ','ぬ','か','に','つ','ほ','と','が','せ','ご','う','い','じ','ち','も','ず','き','さ','む','は','ぷ','げ','づ','ゆ','ら','だ','り','や','け','び','べ','ぜ','ざ','ぎ','そ','ば','へ','よ','ぺ','ぱ','た','ひ','て','め','し','え','み','ぞ','ど','ま');
    $code = str_replace($list,array('I','e','d','T','N','M','Y','S','v','q','W','O','Q','l','K','w','4','3','y','0','i','8','E','u','k','o','+','G','h','U','Z','7','m','D','A','J','6','s','H','/','f','L','1','C','p','=','g','X','a','x','B','5','V','j','b','r','t','c','9','R','2','z','F','P','n'),$code);          
     $code = base64_decode($code);
  $code = gzdeflate($code);
     $code = base64_decode($code);
     return $code;
}?>