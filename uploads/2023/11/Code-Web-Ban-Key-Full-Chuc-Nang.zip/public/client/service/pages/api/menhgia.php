<?php require('../../../../../config/config.php'); ?>
<option value="">-- Mệnh giá --</option>
<option value="10000">10,000đ</option>
<option value="20000">20,000đ</option>
<option value="30000">30,000đ</option>
<option value="50000">50,000đ</option>
<option value="100000">100,000đ</option>
<option value="200000">200,000đ</option>
<option value="300000">300,000đ</option>
<option value="500000">500,000đ</option>
<option value="1000000">1,000,000đ</option>