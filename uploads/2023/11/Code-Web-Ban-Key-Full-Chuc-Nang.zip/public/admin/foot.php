
  <footer class="main-footer">
    <strong>Hệ thống được thiết kế bởi : <a href="https://wwww.zalo.me/0528139892">ManhDev</a></strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 4.0
    </div>
  </footer>
</div>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="b9e3e84309a92aaf852234bf-|49" defer=""></script>
<script src="/public/admin/plugins/jquery/jquery.min.js"></script>
<script src="/public/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/public/admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="/public/admin/dist/js/adminlte.js"></script>
<script src="/public/admin/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="/public/admin/plugins/raphael/raphael.min.js"></script>
<script src="/public/admin/plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="/public/admin/plugins/jquery-mapael/maps/usa_states.min.js"></script>
<script src="/public/admin/plugins/chart.js/Chart.min.js"></script>
<script src="/public/admin/dist/js/demo.js"></script>
<script src="/public/admin/dist/js/pages/dashboard2.js"></script>
</body>
</html>
