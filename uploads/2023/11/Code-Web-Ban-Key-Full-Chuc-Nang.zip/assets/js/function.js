console.log(
    "%c Website: KEYVIPP.COM %c",
    'font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;font-size:15px;color:#ffaa56;-webkit-text-stroke: 1px #ffaa56;',
    "font-size:12px;color:#999999;"
);
console.log(
    "%c Code By: Mạnh Dev %c",
    'font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;font-size:15px;color:#00ff7f;-webkit-text-stroke: 1px #00ff7f;',
    "font-size:12px;color:#999999;"
);
console.log(
    "%c Zalo: 0528139892 %c",
    'font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;font-size:15px;color:#00bbee;-webkit-text-stroke: 1px #00bbee;',
    "font-size:12px;color:#999999;"
);
console.log(
    "%c Note: Tạo 1 Website Hoàn Hảo Khi Liên Hệ Với Tôi - Code Do Tôi Viết - Bao Lỗi Cho Bạn, Sự Tin Dùng Của Bạn Là Niềm Vui Của Tôi %c",
    'font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;font-size:15px;color:#007fff;-webkit-text-stroke: 1px #007fff;',
    "font-size:12px;color:#999999;"
);