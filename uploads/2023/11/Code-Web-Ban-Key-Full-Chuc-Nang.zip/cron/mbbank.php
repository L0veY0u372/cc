<?php
include $_SERVER['DOCUMENT_ROOT'].'/config/config.php';

 $dataPost = array(
 "Loai_api" => "lsgdv2",
 );
 $curl = curl_init();
 curl_setopt_array($curl, array(
 CURLOPT_URL => "https://api.dichvudark.vn/api/ApiMbBankttt",
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_SSL_VERIFYPEER => false,
 CURLOPT_MAXREDIRS => 10,
 CURLOPT_TIMEOUT => 30,
 CURLOPT_CUSTOMREQUEST => "POST",
 CURLOPT_POSTFIELDS => $dataPost,
 CURLOPT_HTTPHEADER => array(
  "Code: rVejrvb6qt4NevN294ytu8P6NCz7q5JPEGVtEgWdPf64d36Tyy5jsSngPcefxHMkwsU2r2QDpacmhGRw3LTVrtwRxWJmvRvJuGZSdNs3YdXvVQRRu5tN3c8dZbC985bn5JTDaqnG24LWg7XN87SYwH9aQYMWeJcKeHaJ8fLKkPSG8daEr3ZNU3mKTrA9rbmMPJwELN5xjfTYSDJFYjHpNsYbCNbFFheZgEZmcgnXYUdXxFGUBK79pqhG9DJt3cvhf4aEbwaLK9bVQkRF3q4rPCnP9mfRKqrEvFYmjLfdvnpavqRUzaQp2dPUffNTVLXTDuPbqZ5HmBtPJ47sMP6nGAyg8AeSJ8zDBywuGQpwg9FVfrUA7LuyD4VLB3dVdUmjr7mvDj2bj7KdRZsRFdmUPruQkwYrmVzF889RfaQdjzdMhAbXMUjXcY3hTrSRAz26XSdkB3G9jn2aDk6gZC6HAUqx7JBahtE2k7uCyVpVLy5FScWeM7P8brcTSSaMcUdNgLzW8srFfwak6WB6XfJN6nEzn6Fj639AQWbFse7e3m3F4KfrwHaswPCj55ffdGkbcV4zEfm8YgwVvGMp3DXTqJSWhpsQmeV7krab37AxjvNp2qgVjGuhxLrnshgxSeQ69UYntgV3hgYzPJbCemwmsc3np2qENZFygEasmk7HqcVpAUHJHZfvUK5XWcKhKVTd32bZDkvXfMVVfPBewng6YVbzt368DW9SQe8rfcaZHfpMQgHnKYxenweP9vHXwcJU6f3aCPwt5cFGaBcg872fpbGZknMbD9chw4tKjfCCSXYbgr9BJF5dchS6DQdknjjUMbzaQnec3BNhYZV2jBmgULSa6fWcUmXEKRbcsvXWNSg8nfVhJ3e6BRrzV86hcTu9wz22hqTRedzgTDDVmtS5uRRmYNxWKSwWtep5ngELxZDKv3m8QVkyErGRZwksHUxxrbdfgcNGv5M6HaqzPNuXkcDXmjUDV3rqg5AKeDtteYxg4jqgtztRxrVqtpMYnR5UE2mpACER2QAW29LFm2Q6QvXr3W62QRsSVqSZeeENjJ7KAxu2m2GBMTH5zCnzVHCMm5eG64XAaJYxHLaxuK4HKUWahYa2NAAkaqy5kXJLkCPxrGcb4HrA9qgtkmdSk6HaPpsCae9pfPVK6UddGcHFuAPtNqMMFB9g9EXkLuCUhyQPKnBpYp4mkFYnzHXn4MSHAUr8QL5a3J29t4UgH4hJVSM348HREfmC8guGGbdBW8dPtr7vaP3CrLYhjCQEuVUXsasTY9UGskMtt2QL9e8qM6hFTHYQ8rR46Tbh7TMy2bMxCEQpbF3yMCxXytnL2tUwS5YVWNTExqr82KCCeQjmwk63uwZ2tb9wCmFZTpR82NLBB2PyjhGAth4vR5DaknqX7XaDX3wgnx5FJXxHfnCMNFuXBEkbNszAdwWE79EDGaqUntPRwzVGRXQHHE3sYG9H9PKNHWnU3QP7MBYCu4pMfp7hSD2HVZh46R4MMYJgv7Nn7dRwQQBTAmZgcjmNwa2uv3GbYaaxH3WrNfbN9pCr8YtqgsWpXW7DeEDSv7kmbb6yHBg3hadHF69u6s2NQDjrQfFSe95frF8YtTDRMjtU6LzQ9HWJW8myA83C2G4Myzb9X2cnD8Qg2PhnV8tuwAGwukbp5sxUu4Ej4jDbfvq7G4PjKZCFNEQqMBmSBSbBLe6MYKReHySGE9BdB9jS7aD4JLSQAhzJmzVKLGLKCpG7r5GBpp6TRmLCCdUeA6fb3Cyn93xJqJUrGFBEmP43fxJvQS6rkVBHBnG9d6XZYXN5bSazV7uFG27Nu9y4hQpMJ54hMVRNsDGrV6hjeQDtmDRVVYJLrDkhPsgvEQ3DvePBWVVrXeeSrEq2mp7KuJt5zEzgGSbvPubdVnELqp7zb7tujyZDG3Fc4jEBwV6JHwA34KdAvVqu9kmqdEkKWGJKftFeSTuVNgyDXh2fJLnhtF28s7xVumyqYyzNVRjTCG8e3yag8hTc3UhPFUyfatSGYeEP8mBsDRtekAgBTymnAMTR",
 "Token: ".$ManhDev->get_row("SELECT * FROM `options` WHERE `key_code` = 'api_key_mbbank' ")['value'],
 "Stk: ".$ManhDev->get_row("SELECT * FROM `options` WHERE `key_code` = 'stk_mbbank' ")['value'])
 ));
 $response = curl_exec($curl);
 curl_close($curl);
 $ketqua = json_decode($response, true);
 $tranList = $ketqua['transactionHistoryList'];
 if(empty($tranList)) {
     echo json_encode([
         "error" => '1',
         "messenger" => 'Lỗi Khi Get - Có Thể Là Chưa Có Giao Dịch',
         'data' => $response
         ]);
 } else {
     $list = [];
     for($f=0;$f<count($tranList);$f++) {
         
         if($tranList[$f]['creditAmount'] >= "1") {
         $phoneMy     = $tranList[$f]['accountNo']; #stk của tôi
         $tranId      = explode('\\', $tranList[$f]['refNo'])[0]; #mã giao dịch
         $money       = $tranList[$f]['creditAmount']; #số tiền
         $comment     = $tranList[$f]['description']; #nội dung
         
         $noidung = $ManhDev->get_row("SELECT * FROM `options` WHERE `key_code` = 'nd_bank' ")['value'];
         $user_bank1 = explode(' ', explode($noidung, $comment)[1])[0];
         $user_bank2 = explode('.', explode($noidung, $comment)[1])[0];
         
         
         $history_Momo = $ManhDev->query("SELECT * FROM `cron` WHERE `tranId` = '$tranId' ")->fetch_array();
         if(!$history_Momo) {
             $info_user = $ManhDev->get_row("SELECT * FROM `users` WHERE `username` = '$user_bank1' OR `username` = '$user_bank2' ");
             if($info_user) {
                $cong_nap_user   = $info_user['tong_nap'] + $money;
                $cong_tien_user  = $info_user['money'] + $money;
                
         $ManhDev->insert("cron", [
                'username'    => $info_user['username'],
                'phone'       => $phoneMy,
                'tranId'      => $tranId,
                'partnerId'   => NULL,
                'partnerName' => NULL,
                'partnerCode' => 'Mb bank',
                'amount'      => $money,
                'comment'     => $comment,
                'time'        => $time
                ]);
         
         $ManhDev->update("users", [
            'money' => $cong_tien_user,
            'tong_nap' => $cong_nap_user
            ], " `username` = '".$info_user['username']."' ");
         
         $ManhDev->insert("log_site", [
                'username'   => $info_user['username'],
                'type'       => 'money',
                'note'       => "Nạp Mb Bank Auto Thành Công! Nhận Được: ".$money." Coin",
                'ip'         => getip(),
                'useragent'  => $_SERVER["HTTP_USER_AGENT"],
                'time'       => $time
                ]);
         
         $list[] = [
             "error" => '0',
             'phone' => $phoneMy,
             'tranId' => $tranId,
             'partnerCode' => 'Mb Bank',
             'amount' => $money,
             'comment' => $comment,
             'user1' => $user_bank1,
             'user2' => $user_bank2
             ];
         } else {
             $list[] = [
                 "error" => '1',
                 "messenger" => 'Username Không Tồn Tại',
                 'data' => $comment,
                 'bank1' => $user_bank1,
                 'bank2' => $user_bank2
                 ];
         }
         
        } else {
            $list[] = [
                 "error" => '1',
                 "messenger" => 'Mã Giao Dịch Đã Tồn Tại',
                 'data' => $tranId
                 ];
        }
       }
     }
     die(json_encode([
             "data" => $list
             ]));
 }