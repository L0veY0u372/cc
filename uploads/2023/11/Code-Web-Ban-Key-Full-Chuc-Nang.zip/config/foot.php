</div>
</div>

<footer class="footer">
<div class="container-fluid">
<p class="clearfix mb-0 text-center"> Copyright <a href="javascript:void(0);" class="text-primary"><?=$ManhDev->site('nameWeb');?></a> © <?=date('Y');?> All right reserved. Website Được Vận Hành Bởi <a href="//zalo.me/<?=$ManhDev->site('phoneAdmin');?>" class="text-danger"><?=$ManhDev->site('nameAdmin');?></a></p>
</div>
</footer>
</div>
</div>
<style>
    .form-group {
    margin-top: 10px;
}
</style>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="/assets/js/bootstrap.bundle.min.js?<?=time();?>"></script>
<script src="/assets/js/metismenujs.min.js?<?=time();?>"></script>
<script src="/assets/js/simplebar.min.js?<?=time();?>"></script>
<script src="/assets/js/eva.min.js?<?=time();?>"></script>
<script src="/assets/js/app.js?t=<?=time();?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
</body>
</html>