<?php include $_SERVER['DOCUMENT_ROOT'].'/config/head.php';
if(empty($ManhDev->users('username'))) {
echo "<script>location.href = '/auth/login'</script>";
}
?>
<title>Spam Sms Call</title>
<html lang="en">
	<!--begin::Head-->
	<head><base href=""/>

		<link rel="shortcut icon" href="../../assets/media/logos/favicon.ico" />
		<!--begin::Fonts(mandatory for all pages)-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(mandatory for all pages)-->
		<link href="https://shopdragonx.com/assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="https://shopdragonx.com/assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Global Stylesheets Bundle-->
	</head>
<body>
<style>
  .round-rectangle-button {
    display: inline-block;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    cursor: pointer;
    margin-right: 10px;
  }

  .start-button {
    background-color: green;
    color: white;
  }

  .stop-button {
    background-color: red;
    color: white;
  }
</style>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/nav.php'; ?>
    <!--begin::Main-->
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
       <!--begin::Content wrapper-->
<div class="d-flex flex-column flex-column-fluid">
    <!--begin::Toolbar-->
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        <!--begin::Toolbar container-->
        <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <!--begin::Title-->

                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ol class="breadcrumb text-muted fs-6 fw-semibold">
                    <li class="breadcrumb-item pe-3"><a href="/home" class="pe-3">Trang Chủ</a></li>
                    <li class="breadcrumb-item pe-3"><a href="#" class="pe-3"> Spam Sms Call</a></li>
                </ol>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar container-->
    </div>
    <!--end::Toolbar-->
</div>
<?php
if (isset($_POST['phone'])) {
    $phone = $_POST['phone'];
    
    if ($_POST['server'] == 'server1') {
        $time_limit = 60;
        $blacklist = array(
            '0335395153',
            '0399498820',
            '0385315877',
            '0777374145'
        );
        if (empty($phone)) {
            echo '<script type="text/javascript">alert("Thiếu số điện thoại!"); setTimeout(function(){ location.href = "/" }, 1000);</script>';
        } else if (in_array($phone, $blacklist)) {
            echo '<script type="text/javascript">alert("Spam Thành Công!");</script>';
            echo '<script type="text/javascript">alert("Đùa Đấy tuổi gì mà đòi spam số anh😝!");</script>';
        } else {
            echo '<script type="text/javascript">alert("Spam Thành Công!");</script>';
            $data = array('phone' => $phone);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://api.huykaiser.me/API/AUTOSPAM/spam?count=100&apikey=HUYKAISER_CUTO_OK&phone=' . urlencode($phone));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            if ($_POST['server'] == 'server1') {
                $time_limit = 60;
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_limit);
            } else if ($_POST['server'] == 'server2') {
                $time_limit = 120;
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time_limit);
            } else {
                echo '<script type="text/javascript">alert("Server không hợp lệ!");</script>';
                exit();
            }

            $response = curl_exec($ch);
            curl_close($ch);
        }
    }
} else {
    echo '<script type="text/javascript">alert("Trường Phone Không Được Để Trống!");</script>';
}
?>
<!--end::Content wrapper-->
<div class="row">
<div class="col-md-12">
<div class="alert alert-primary mb-3" role="alert">
- Spam Sms Call Cực Vip Của Nguyễn Văn Huy X HuyKaiser<br>
- API By HuyKaiser Và Api Này Có Nhiều Api Call Và Sms Khác Nhau Nên Siêuu Ngonn<br>
- Free Server Spam V1 Siêu Ngon.
</div>
</div>
 <form action="" method="post"> 
<div class="col-md-6 mb-3">
<div class="card">
            <div class="card-header">
                <h3 class="card-title">SPAM SMS CALL BY HUYKAISER X SONG UY</h3></div>
            <div class="card-body">
<div class="row p-3">
<div class="col-md-12">
    <div class="form-group">
    <div class="form-group">
        <label class="form-label" for="phone">Phone Cần Spam :</label>
        <input class="form-control" id="phone" name="phone" type="number" placeholder="Nhập Phone Cần Spam">
    </div>
    <div class="form-group">
        <label class="form-label" for="soluong">Số lượng Spam :</label>
        <input class="form-control" id="soluong" name="soluong" type="number" placeholder="Nhập Số lượng Spam :">
    </div>
    <div class="form-group">
        <label class="col-sm-12 col-md-2 col-form-label">Chọn server</label>
        <select class="form-control" id="server" name="server">
            <option value="server1">Server 1 | 60s | Free</option>
            <option value="server2">Server 2 | 120s | Free</option>
        </select>
    </div>
    <br>
    <button type="submit" name="submit" class="btn btn-success btn-block mb-2" id="batdau">Attack Spam</button>
</form>
                    </div>
                </div>
           <div>
    </div>
<div>  
		<!--end::Modal - Invite Friend-->
		<!--end::Modals-->
		<!--begin::Javascript-->
		<script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(mandatory for all pages)-->
		<script src="https://shopdragonx.com/assets/plugins/global/plugins.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/js/scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Vendors Javascript(used for this page only)-->
		<script src="https://shopdragonx.com/assets/plugins/custom/fslightbox/fslightbox.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/plugins/custom/typedjs/typedjs.bundle.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
		<script src="https://shopdragonx.com/assets/plugins/custom/datatables/datatables.bundle.js"></script>
		<!--end::Vendors Javascript-->
		<!--begin::Custom Javascript(used for this page only)-->
		<script src="https://shopdragonx.com/assets/js/widgets.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/widgets.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/apps/chat/chat.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/upgrade-plan.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/type.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/budget.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/settings.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/team.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/targets.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/files.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/complete.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/main.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-campaign.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/bidding.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/users-search.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-app.js"></script>
		<!--end::Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<br>
	</br>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/foot.php';?>