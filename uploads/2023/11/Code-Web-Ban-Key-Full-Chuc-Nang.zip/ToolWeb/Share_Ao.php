<?php include $_SERVER['DOCUMENT_ROOT'].'/config/head.php';
if(empty($ManhDev->users('username'))) {
echo "<script>location.href = '/auth/login'</script>";
}
?>
<title>Tool Share Ảo</title>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/nav.php'; ?>

<div class="row">
<div class="col-md-12">
<div class="alert alert-primary mb-3" role="alert">
- Đặc Biệt, From Này Không Yêu Cầu Setup, Tải Tool, Tải Termux - ISh,...<br> 
- Chỉ Cần Nhập Thông Tin Là Dùng.
</div>
</div>
    <div class="col-md-6 col-lg-6 col-xl-4 mb-3">
        <div class="card m-b-30">
            <div class="card-body">
               
                    <div class="form-group">
                        <label class="form-label" for="cookie">Cookie Tài Khoản :</label>
                        <input class="form-control" id="cookie" placeholder="Nhập Cookie Fb">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="idbv">ID Bài Viết Cần Share : (Lấy ID <a href="https://id.traodoisub.com">Tại đây</a>)</label>
                        <input class="form-control" id="idbv" placeholder="Nhập ID Bài Viết">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="soluong">Số Lượng Share :</label>
                        <input class="form-control" id="soluong" placeholder="Nhập Số Lượng Share"><br>
                    </div>
                    <div class="pricing-bottom pricing-bottom-basic mt-3">
                        <div class="pricing-btn">
                            <button type="button" class="btn btn-success font-16" id="batdau">Chạy Ngay</button>       
                            <a href="" class="btn btn-danger font-16">Dừng Tool</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<label class="form-label text-primary" for="dataSuccess">Kết Quả:</label>
<div class="col-md-6 col-sm-6 col-lg-4 mb-2">
            <div class="card card-body" id="divVuHoangDev">
                <div class="dulieutrave" data-row="1">
                    <div id="dataSuccess">
                    </div>
        </div>
    </div>
</div>
</div>


<script type="text/javascript">
$(document).ready(function(){
    $('#batdau').click(function() {
        $('#batdau').html('Đang Thực Hiện...').prop('disabled', true);
        var old = $('#dataSuccess').html().toString();
        var shareao = {
            'cookie'     : $("#cookie").val(),
            'soluong'     : $("#soluong").val(),
            'idbv'   : $("#idbv").val()
        };
        $.post("/apiv2/api-shareao.php", shareao, function (data) {
            $('#divVuHoangDev').append(data);
        });
    });
});

		</script>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/foot.php';?>
