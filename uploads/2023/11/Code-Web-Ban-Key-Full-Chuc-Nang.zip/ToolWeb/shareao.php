<?php include $_SERVER['DOCUMENT_ROOT'].'/config/head.php';
if(empty($ManhDev->users('username'))) {
echo "<script>location.href = '/auth/login'</script>";
}
?>
<title>Share Ảo Vip</title>
<html lang="en">
	<!--begin::Head-->
	<head><base href=""/>

		<link rel="shortcut icon" href="../../assets/media/logos/favicon.ico" />
		<!--begin::Fonts(mandatory for all pages)-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(mandatory for all pages)-->
		<link href="https://shopdragonx.com/assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="https://shopdragonx.com/assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Global Stylesheets Bundle-->
	</head>
<body>
<style>
  .round-rectangle-button {
    display: inline-block;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    cursor: pointer;
    margin-right: 10px;
  }

  .start-button {
    background-color: green;
    color: white;
  }

  .stop-button {
    background-color: red;
    color: white;
  }
</style>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/nav.php'; ?>
    <!--begin::Main-->
    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
       <!--begin::Content wrapper-->
<div class="d-flex flex-column flex-column-fluid">
    <!--begin::Toolbar-->
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        <!--begin::Toolbar container-->
        <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <!--begin::Title-->

                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ol class="breadcrumb text-muted fs-6 fw-semibold">
                    <li class="breadcrumb-item pe-3"><a href="/home" class="pe-3">Trang Chủ</a></li>
                    <li class="breadcrumb-item pe-3"><a href="#" class="pe-3"> Tool Share Ảo</a></li>
                </ol>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar container-->
    </div>
    <!--end::Toolbar-->
</div>
<!--end::Content wrapper-->
<div class="row g-5 g-xl-10 mb-5 mb-xl-10">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
               <div class="row">
<div class="col-md-12">
<div class="alert alert-primary mb-3" role="alert">
- Tham Gia Nhóm Chat Zalo Để Cập Nhật Thông Báo Từ Quản Trị Viên <a href="https://zalo.me/g/untpfo683">Tại Đây</a><br>
- Đặc Biệt, From Này Không Yêu Cầu Setup, Tải Tool, Tải Termux - ISh,...<br> 
- Chỉ Cần Nhập Thông Tin Là Dùng.
</div>
</div>
    <div class="form-group">
        <label class="form-label" for="cookie">Cookie Tài Khoản :</label>
    <input class="form-control" id="cookie" placeholder="Nhập Cookie Fb">
</div>
    <div class="form-group">
        <label class="form-label" for="idbv">ID Bài Viết Cần Share : (Lấy ID <a href="https://id.traodoisub.com">Tại đây</a>)</label>
        <input class="form-control" id="idbv" placeholder="Nhập ID Bài Viết">
    </div>
    <div class="form-group">
        <label class="form-label" for="soluong">Số Lượng Share :</label>
        <input class="form-control" id="soluong" placeholder="Nhập Số Lượng Share"><br>
    </div>
<div class="round-rectangle-button">
 <button type="button" class="btn btn-success btn-block mb-2" id="batdau">Chạy Ngay</button>       
<a href class="btn btn-danger btn-block mb-2">Dừng Tool</a>
</div>
</br>
<div class="col-md-12">
<div class="alert alert-primary mb-3" role="alert">
    <label class="form-label text-primary" for="dataSuccess">Kết Quả:</label>
    <div class="card card-body" id="divVuHoangDev">
        <div class="dulieutrave" data-row="1">
            <div id="dataSuccess">
            </div>
        </div>
    </div>
</div>
                    </div>
                </div>
           <div>
    </div>
<div>                          
<script type="text/javascript">
$(document).ready(function(){
    $('#batdau').click(function() {
        $('#batdau').html('Đang Thực Hiện...').prop('disabled', true);
        var old = $('#dataSuccess').html().toString();
        var shareao = {
            'cookie'     : $("#cookie").val(),
            'soluong'     : $("#soluong").val(),
            'idbv'   : $("#idbv").val()
        };
        $.post("/apiv2/api-shareao.php", shareao, function (data) {
            $('#divVuHoangDev').append(data);
        });
    });
});

		</script>
		<!--end::Modal - Invite Friend-->
		<!--end::Modals-->
		<!--begin::Javascript-->
		<script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(mandatory for all pages)-->
		<script src="https://shopdragonx.com/assets/plugins/global/plugins.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/js/scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Vendors Javascript(used for this page only)-->
		<script src="https://shopdragonx.com/assets/plugins/custom/fslightbox/fslightbox.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/plugins/custom/typedjs/typedjs.bundle.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
		<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
		<script src="https://shopdragonx.com/assets/plugins/custom/datatables/datatables.bundle.js"></script>
		<!--end::Vendors Javascript-->
		<!--begin::Custom Javascript(used for this page only)-->
		<script src="https://shopdragonx.com/assets/js/widgets.bundle.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/widgets.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/apps/chat/chat.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/upgrade-plan.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/type.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/budget.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/settings.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/team.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/targets.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/files.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/complete.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-project/main.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-campaign.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/bidding.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/users-search.js"></script>
		<script src="https://shopdragonx.com/assets/js/custom/utilities/modals/create-app.js"></script>
		<!--end::Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<br>
	<br>
	<br>
	<br>
<?php include $_SERVER['DOCUMENT_ROOT'].'/config/foot.php';?>