<?php
$sdt = $_POST['phone'];
$spam = json_decode(file_get_contents("https://keysiuvip.tk/spamPhone.php?key=CHAI_MAM999&phone=".$sdt),true);
if ($spam['status'] == "error"){
die(json_encode([
    "status" => "error",
    "msg" => $spam['msg']
    ]));}
elseif ($spam['status'] == "success"){
die(json_encode([
    "status" => "success",
    "msg" => "Đã Hoàn Thành Spam!"
    ]));}
?>